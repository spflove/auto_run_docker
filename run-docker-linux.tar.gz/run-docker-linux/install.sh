#!/bin/bash
# install.sh - 安装 run-docker 命令到用户 PATH
#
# 模式：
#   (无参数)     发布包安装：安装 bin/run-docker/ 二进制到 ~/.local/lib/auto_docker/
#   --uninstall  卸载程序（保留 ~/.config/auto_docker/ 用户配置）

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_BIN="$HOME/.local/bin"
INSTALL_LIB="$HOME/.local/lib/auto_docker"
CONFIG_DIR="$HOME/.config/auto_docker"
CONFIG_FILE="$CONFIG_DIR/user_container.yaml"
CONFIG_TEMPLATE="$SCRIPT_DIR/config/user_container.yaml.example"
RUN_DOCKER_SCRIPT="$INSTALL_BIN/run-docker"
PATH_ENV_FILE="$INSTALL_LIB/path.env"
FEISHU_ENV_FILE="$CONFIG_DIR/feishu.env"
PATH_SOURCE_LINE='[ -f "$HOME/.local/lib/auto_docker/path.env" ] && source "$HOME/.local/lib/auto_docker/path.env"'

# bash install.sh 在子 shell 中运行，无法修改用户当前终端的 PATH；
# source install.sh 则可直接生效。交互式 bash 安装结束后进入继承 PATH 的子 shell。
_is_install_sourced() {
    [ "${BASH_SOURCE[0]}" != "$0" ]
}

_activate_path_env() {
    if [ ! -f "$PATH_ENV_FILE" ]; then
        return 1
    fi
    # shellcheck disable=SC1091
    . "$PATH_ENV_FILE"
}

_enter_configured_shell() {
    # 非交互 / CI / 用户显式跳过时，不替换当前 shell
    _is_install_sourced && return 0
    case "${INSTALL_NO_REEXEC:-}" in
        1|true|yes|Y|y) return 0 ;;
    esac
    [ -t 0 ] && [ -t 1 ] || return 0

    echo ""
    echo "==> 已进入已配置 PATH 的 shell，可直接使用 run-docker"
    echo "    （输入 exit 返回安装前的终端；新开终端亦会自动生效）"
    exec "${SHELL:-/bin/bash}" -i
}

_log_step() {
    echo "==> $*"
}

_log_detail() {
    echo "    $*"
}

# NFS 上若有 run-docker 进程仍占用旧文件，rm 会留下 .nfs* 且失败；优先 mv 迁走再装新目录
_run_docker_stale_dir() {
    echo "$INSTALL_LIB/run-docker.stale.$(date +%Y%m%d_%H%M%S).$$"
}

_quiet_rm_rf() {
    local target="$1"
    rm -rf "$target" 2>/dev/null
}

_prune_stale_run_docker_dirs() {
    local d
    for d in "$INSTALL_LIB"/run-docker.stale.*; do
        [ -e "$d" ] || continue
        _quiet_rm_rf "$d"
    done
}

_relocate_run_docker_lib_dir() {
    local target="$INSTALL_LIB/run-docker"
    [ -e "$target" ] || return 0

    if [ -L "$target" ]; then
        rm -f "$target"
        return 0
    fi

    if [ ! -d "$target" ]; then
        rm -f "$target"
        return 0
    fi

    local stale="$(_run_docker_stale_dir)"
    _log_detail "迁移旧程序目录 $target -> $stale （避免 NFS 占用导致 rm 失败）..."
    if mv "$target" "$stale"; then
        _log_detail "旧目录已迁走；占用结束后可手动删除: $stale"
        _prune_stale_run_docker_dirs || true
        return 0
    fi

    _log_detail "迁移失败，尝试直接删除（仍有进程占用时会残留 .nfs 文件）..."
    if rm -rf "$target" 2>/dev/null; then
        return 0
    fi

    echo "✗ 无法清理旧程序目录: $target"
    echo "  常见原因: 本节点仍有 run-docker / batch-more 子任务在运行（NFS 文件被占用）"
    echo "  建议:"
    echo "    1) 查看占用: lsof +D $target 2>/dev/null | head"
    echo "    2) 等待任务结束，或 run-docker -m --stop -as / run-docker --stop <时间戳>"
    echo "    3) 再执行: bash install.sh"
    echo "  说明: 已在运行的任务会继续使用迁走前的旧二进制；新装成功后未派发子任务会用新版本"
    return 1
}

# 复制发布包到 ~/.local/lib，并显示进度（安装后无需保留发布包目录）
_copy_bundle_with_progress() {
    local src="$1"
    local dst="$2"
    local total_mb total_kb total_human

    total_mb="$(du -sm "$src" 2>/dev/null | awk '{print $1}')"
    total_kb="$(du -sk "$src" 2>/dev/null | awk '{print $1}')"

    mkdir -p "$(dirname "$dst")"
    if [ -e "$dst" ]; then
        if ! _relocate_run_docker_lib_dir; then
            echo "✗ 无法准备安装目录: $dst"
            exit 1
        fi
    fi

    if command -v rsync >/dev/null 2>&1; then
        echo "    安装中... 0%"
        if rsync --help 2>&1 | grep -q 'progress2'; then
            rsync -a --info=progress2 "$src/" "$dst/"
        else
            rsync -a --progress "$src/" "$dst/"
        fi
        echo ""
        echo "    安装中... 100% 复制完成"
        return 0
    fi

    if command -v pv >/dev/null 2>&1 && [ -n "$total_kb" ] && [ "$total_kb" -gt 0 ]; then
        mkdir -p "$dst"
        echo "    安装中... 0%"
        tar -C "$src" -cf - . | pv -s "${total_kb}k" -f -p -t -e -r | tar -C "$dst" -xf -
        echo ""
        echo "    安装中... 100% 复制完成"
        return 0
    fi

    # 无 rsync/pv：后台 cp + 轮询目录大小
    echo "    安装中... 0%"
    cp -a "$src" "$dst" &
    local cp_pid=$!
    local last_pct=-1

    while kill -0 "$cp_pid" 2>/dev/null; do
        if [ -n "$total_mb" ] && [ "$total_mb" -gt 0 ] && [ -d "$dst" ]; then
            local done_mb pct
            done_mb="$(du -sm "$dst" 2>/dev/null | awk '{print $1}')"
            pct=$(( done_mb * 100 / total_mb ))
            if [ "$pct" -gt 100 ]; then pct=100; fi
            if [ "$pct" -ne "$last_pct" ]; then
                echo "    安装中... ${pct}% (${done_mb}MB / ${total_mb}MB)"
                last_pct=$pct
            fi
        else
            echo "    安装中..."
        fi
        sleep 2
    done

    if ! wait "$cp_pid"; then
        echo "✗ 复制程序失败"
        exit 1
    fi
    echo "    安装中... 100% 复制完成"
}

RELEASE_BINARY="$SCRIPT_DIR/bin/run-docker/run-docker"
DEV_SOURCE="$SCRIPT_DIR/run_codes/run_docker.py"

# 从 shell 配置文件移除 auto_docker 相关条目
_cleanup_shell_rc() {
    local rc="$1"
    [ -f "$rc" ] || return 0
    local temp_file
    temp_file=$(mktemp)
    grep -v '# auto_docker install' "$rc" \
        | grep -v '# auto_docker feishu' \
        | grep -v 'auto_docker/feishu.env' \
        | grep -v 'auto_docker/path.env' \
        | grep -v '.config/auto_docker/feishu.env' \
        | grep -v '.local/lib/auto_docker/path.env' \
        | grep -v 'export PATH="$HOME/.local/bin:$PATH"' > "$temp_file" || true
    sed '/^$/N;/^\n$/D' "$temp_file" > "${rc}.tmp" && mv "${rc}.tmp" "$rc"
    rm -f "$temp_file"
}

_append_shell_line() {
    local rc="$1"
    local marker="$2"
    local line="$3"
    if [ -f "$rc" ]; then
        grep -qF "$marker" "$rc" && return 0
        grep -qF "$line" "$rc" && return 0
    else
        touch "$rc"
    fi
    echo '' >> "$rc"
    echo "$marker" >> "$rc"
    echo "$line" >> "$rc"
}

install_path_env() {
    mkdir -p "$(dirname "$PATH_ENV_FILE")"
    cat > "$PATH_ENV_FILE" << 'PATH_EOF'
# auto_docker install - PATH 配置（由 install.sh 生成）
export PATH="$HOME/.local/bin:$PATH"
PATH_EOF

    for rc in "$HOME/.bash_profile" "$HOME/.profile" "$HOME/.bashrc" "$HOME/.zshrc"; do
        _append_shell_line "$rc" '# auto_docker install' "$PATH_SOURCE_LINE"
    done
}

install_user_config() {
    mkdir -p "$CONFIG_DIR"

    if [ -f "$CONFIG_FILE" ]; then
        echo "✓ 保留已有配置: $CONFIG_FILE"
        return 0
    fi

    if [ -f "$CONFIG_DIR/.default_config_disabled" ]; then
        echo "ℹ 已启用个人配置模式（共享默认 yaml 已禁用），跳过创建 $CONFIG_FILE"
        echo "  各用户请执行: run-docker use-config \$HOME/<个人目录>/yx_dockerspace/user_container.yaml"
        return 0
    fi

    if [ -f "$CONFIG_TEMPLATE" ]; then
        cp "$CONFIG_TEMPLATE" "$CONFIG_FILE"
    elif [ -f "$SCRIPT_DIR/user_container.yaml" ]; then
        cp "$SCRIPT_DIR/user_container.yaml" "$CONFIG_FILE"
    else
        echo "✗ 未找到配置模板: $CONFIG_TEMPLATE"
        exit 1
    fi

    chmod 600 "$CONFIG_FILE"
    echo "✓ 已创建配置文件: $CONFIG_FILE"
    echo "  请按节点环境编辑后再使用 run-docker"
}

_cleanup_feishu_env_from_shell() {
    local rc="$1"
    [ -f "$rc" ] || return 0
    local temp_file
    temp_file=$(mktemp)
    grep -v '# auto_docker feishu' "$rc" \
        | grep -v 'auto_docker/feishu.env' \
        | grep -v '.config/auto_docker/feishu.env' > "$temp_file" || true
    sed '/^$/N;/^\n$/D' "$temp_file" > "${rc}.tmp" && mv "${rc}.tmp" "$rc"
    rm -f "$temp_file"
}

remove_legacy_feishu_env() {
    for rc in "$HOME/.bash_profile" "$HOME/.profile" "$HOME/.bashrc" "$HOME/.zshrc"; do
        if [ -f "$rc" ] && grep -q 'auto_docker/feishu.env\|# auto_docker feishu' "$rc" 2>/dev/null; then
            _cleanup_feishu_env_from_shell "$rc"
        fi
    done
    if [ -f "$FEISHU_ENV_FILE" ]; then
        rm -f "$FEISHU_ENV_FILE"
    fi
}

remove_program_files() {
    _log_detail "清理旧 run-docker 命令..."
    [ -f "$RUN_DOCKER_SCRIPT" ] && rm -f "$RUN_DOCKER_SCRIPT"
    [ -f "$INSTALL_BIN/run_docker" ] && rm -f "$INSTALL_BIN/run_docker"

    if [ -e "$INSTALL_LIB/run-docker" ]; then
        _relocate_run_docker_lib_dir || exit 1
    fi

    # 兼容旧版安装路径
    if [ -d "$INSTALL_BIN/auto_docker" ]; then
        _log_detail "清理旧版 ~/.local/bin/auto_docker/ ..."
        rm -rf "$INSTALL_BIN/auto_docker" 2>/dev/null || true
    fi
}

uninstall_run_docker() {
    remove_program_files

    for rc in "$HOME/.bashrc" "$HOME/.bash_profile" "$HOME/.profile" "$HOME/.zshrc"; do
        _cleanup_shell_rc "$rc"
    done
}

# 生成 ~/.local/bin/run-docker wrapper（发布版/开发版共用逻辑）
# 公用账户场景：各用户在 $HOME/<个人目录>/ 下放置 user_container.yaml，
# 执行 run-docker use-config 绑定后，在该个人目录及其子目录内 run-docker 自动生效。
_write_run_docker_wrapper() {
    local exec_line="$1"
    {
        cat << 'WRAPPER_EOF'
#!/bin/bash
# run-docker wrapper（由 install.sh 自动生成，请勿手动修改）

_RUN_DOCKER_DEFAULT_CONFIG="$HOME/.config/auto_docker/user_container.yaml"
_RUN_DOCKER_CONFIG_DIR="$HOME/.config/auto_docker"
_RUN_DOCKER_DEFAULT_DISABLED_MARKER="$_RUN_DOCKER_CONFIG_DIR/.default_config_disabled"

_run_docker_abs_path() {
    local p="$1"
    if [ -z "$p" ]; then
        return 1
    fi
    if [ -d "$p" ]; then
        (cd "$p" && pwd)
    elif [ -f "$p" ]; then
        echo "$(cd "$(dirname "$p")" && pwd)/$(basename "$p")"
    else
        local dir
        dir="$(dirname "$p")"
        if [ -d "$dir" ]; then
            echo "$(cd "$dir" && pwd)/$(basename "$p")"
        else
            return 1
        fi
    fi
}

# 个人 yaml 须在 $HOME/<用户名>/... 下，不可放在 $HOME/.config 等隐藏目录
_run_docker_is_personal_config_path() {
    local yaml_abs="$1"
    local home_abs rel first_seg

    home_abs="$(_run_docker_abs_path "$HOME")" || home_abs="$HOME"
    case "$yaml_abs" in
        "$home_abs"/*) ;;
        *) return 1 ;;
    esac

    rel="${yaml_abs#"$home_abs"/}"
    first_seg="${rel%%/*}"
    [ -n "$first_seg" ] || return 1
    [ "${first_seg#.}" = "$first_seg" ] || return 1
    return 0
}

_run_docker_use_config() {
    local yaml_path="${1:-}"
    local yaml_abs env_file env_dir

    if [ -z "$yaml_path" ]; then
        echo "用法: run-docker use-config <user_container.yaml 路径>"
        echo ""
        echo "示例（公用账户 public_user，每人有自己的顶层目录）:"
        echo "  run-docker use-config \$HOME/zhangs1/yx_dockerspace/user_container.yaml"
        echo "  run-docker use-config \$HOME/songlf/yx_dockerspace/user_container.yaml"
        echo ""
        echo "绑定后在个人目录及其子目录下执行 run-docker 即可自动使用该 yaml。"
        echo ""
        echo "注意: use-config 会删除共享默认配置 ~/.config/auto_docker/user_container.yaml，"
        echo "      此后仅允许使用个人 yaml（公用账户上任意一人执行后即全局生效）。"
        return 1
    fi

    yaml_abs="$(_run_docker_abs_path "$yaml_path")" || {
        echo "✗ 无法解析路径: $yaml_path"
        return 1
    }
    if [ ! -f "$yaml_abs" ]; then
        echo "✗ 配置文件不存在: $yaml_abs"
        return 1
    fi
    if ! _run_docker_is_personal_config_path "$yaml_abs"; then
        echo "✗ 请使用个人目录下的 yaml，例如:"
        echo "    \$HOME/zhangs1/yx_dockerspace/user_container.yaml"
        echo "  共享默认路径 \$HOME/.config/auto_docker/ 不适合 use-config 绑定。"
        return 1
    fi

    env_dir="$(dirname "$yaml_abs")"
    env_file="$env_dir/.run-docker.env"
    cat > "$env_file" << ENV_EOF
# run-docker 个人配置（由 run-docker use-config 生成）
export RUN_DOCKER_CONFIG="$yaml_abs"
ENV_EOF
    chmod 600 "$env_file" 2>/dev/null || true

    # 安全策略：绑定个人配置后禁用共享默认 yaml
    mkdir -p "$_RUN_DOCKER_CONFIG_DIR"
    touch "$_RUN_DOCKER_DEFAULT_DISABLED_MARKER"
    chmod 600 "$_RUN_DOCKER_DEFAULT_DISABLED_MARKER" 2>/dev/null || true

    if [ -f "$_RUN_DOCKER_DEFAULT_CONFIG" ]; then
        rm -f "$_RUN_DOCKER_DEFAULT_CONFIG"
        echo "  已删除共享默认配置: $_RUN_DOCKER_DEFAULT_CONFIG"
    fi

    echo "✓ 已绑定个人配置"
    echo "  yaml:      $yaml_abs"
    echo "  标记文件:  $env_file"
    echo ""
    echo "  此后不再使用共享默认配置；请在个人目录及其子目录下执行 run-docker。"
    echo "  也可手动: export RUN_DOCKER_CONFIG=\"$yaml_abs\""
    return 0
}

# 从 $PWD 向上查找 .run-docker.env，搜索范围限定在 $HOME 内（公用账户安全边界）
_run_docker_discover_config() {
    if [ -n "${RUN_DOCKER_CONFIG:-}" ]; then
        return 0
    fi

    local dir="$PWD"
    local home_abs
    home_abs="$(_run_docker_abs_path "$HOME")" || home_abs="$HOME"

    while [ -n "$dir" ] && [ "$dir" != "/" ]; do
        if [ -f "$dir/.run-docker.env" ]; then
            # shellcheck disable=SC1090
            source "$dir/.run-docker.env"
            if [ -n "${RUN_DOCKER_CONFIG:-}" ] && [ -f "$RUN_DOCKER_CONFIG" ]; then
                return 0
            fi
            unset RUN_DOCKER_CONFIG
        fi
        if [ "$dir" = "$home_abs" ]; then
            break
        fi
        dir="$(dirname "$dir")"
    done
    return 0
}

# 解析最终配置：已禁用默认 yaml 时，不允许回退到 ~/.config/auto_docker/user_container.yaml
_run_docker_resolve_config() {
    _run_docker_discover_config

    if [ -n "${RUN_DOCKER_CONFIG:-}" ] && [ -f "$RUN_DOCKER_CONFIG" ]; then
        return 0
    fi
    unset RUN_DOCKER_CONFIG

    if [ -f "$_RUN_DOCKER_DEFAULT_DISABLED_MARKER" ] || [ ! -f "$_RUN_DOCKER_DEFAULT_CONFIG" ]; then
        echo "✗ 未找到可用的个人配置（共享默认配置已禁用）"
        echo ""
        echo "  请先绑定个人 yaml（只需一次）:"
        echo "    run-docker use-config \$HOME/<个人目录>/yx_dockerspace/user_container.yaml"
        echo ""
        echo "  绑定后在个人目录及其子目录下执行 run-docker，或手动:"
        echo "    export RUN_DOCKER_CONFIG=/path/to/your/user_container.yaml"
        exit 1
    fi

    export RUN_DOCKER_CONFIG="$_RUN_DOCKER_DEFAULT_CONFIG"
    return 0
}

if [ "${1:-}" = "use-config" ]; then
    _run_docker_use_config "${2:-}"
    exit $?
fi

_run_docker_resolve_config
export PYTHONIOENCODING="${PYTHONIOENCODING:-utf-8}"
export LANG="${LANG:-en_US.UTF-8}"
WRAPPER_EOF
        echo "$exec_line"
    } > "$RUN_DOCKER_SCRIPT"
    chmod +x "$RUN_DOCKER_SCRIPT"
}

write_release_wrapper() {
    local binary_path="$INSTALL_LIB/run-docker/run-docker"
    _write_run_docker_wrapper "exec \"$binary_path\" \"\$@\""
}

write_dev_wrapper() {
    local source_root="$SCRIPT_DIR"
    _write_run_docker_wrapper "exec python3 \"$source_root/run_codes/run_docker.py\" \"\$@\""
}

install_release() {
    if [ ! -x "$RELEASE_BINARY" ]; then
        echo "✗ 未找到发布二进制: $RELEASE_BINARY"
        echo "  请先在本机（Linux x86_64）执行: bash build_release.sh"
        echo "  或使用开发安装: bash install.sh --dev"
        exit 1
    fi

    mkdir -p "$INSTALL_BIN" "$INSTALL_LIB"

    local bundle_src="$SCRIPT_DIR/bin/run-docker"
    local bundle_dst="$INSTALL_LIB/run-docker"

    _copy_bundle_with_progress "$bundle_src" "$bundle_dst"

    chmod +x "$INSTALL_LIB/run-docker/run-docker"
    write_release_wrapper
}

install_dev() {
    if [ ! -f "$DEV_SOURCE" ]; then
        echo "✗ 未找到开发源码: $DEV_SOURCE"
        exit 1
    fi

    mkdir -p "$INSTALL_BIN" "$INSTALL_LIB"
    write_dev_wrapper
    echo "✓ 已安装开发版（源码: $SCRIPT_DIR/run_codes/）"
}

resolve_install_mode() {
    local requested="${1:-release}"

    case "$requested" in
        dev)
            echo dev
            return 0
            ;;
        release)
            if [ -x "$RELEASE_BINARY" ]; then
                echo release
                return 0
            fi
            if [ -f "$DEV_SOURCE" ]; then
                echo "⚠ 当前目录无发布包 bin/run-docker/，自动改用开发模式（源码安装）" >&2
                echo "  提示: 修改 user_container.yaml 后无需重新 install，直接 run-docker 即可" >&2
                echo dev
                return 0
            fi
            echo "✗ 无法安装：未找到 $RELEASE_BINARY" >&2
            echo "  请先 bash build_release.sh 生成发布包，或在源码目录使用: bash install.sh --dev" >&2
            exit 1
            ;;
        *)
            echo "✗ 未知安装模式: $requested" >&2
            exit 1
            ;;
    esac
}

refresh_user_config() {
    echo "==> 刷新用户配置（不重装程序）"
    if [ ! -f "$CONFIG_FILE" ]; then
        echo "✗ 配置文件不存在: $CONFIG_FILE"
        echo "  请先执行: bash install.sh 或 bash install.sh --dev"
        exit 1
    fi
    remove_legacy_feishu_env
    echo ""
    echo "✓ 配置已就绪"
    echo "  配置文件: $CONFIG_FILE"
    echo "  飞书请在此 yaml 的 feishu 段维护：user_open_id；可选 app_id/app_secret（须成对），修改后直接 run-docker"
}

install_run_docker() {
    local mode
    mode="$(resolve_install_mode "${1:-release}")"

    _log_step "run-docker 安装开始（模式: $mode）"

    remove_program_files

    mkdir -p "$INSTALL_BIN"

    case "$mode" in
        dev)
            _log_step "安装程序文件..."
            install_dev
            ;;
        release)
            install_release
            ;;
    esac

    _log_step "检查用户配置..."
    install_user_config

    remove_legacy_feishu_env || true

    _log_step "注册 PATH..."
    install_path_env
    _activate_path_env || {
        echo "✗ 无法加载 PATH 配置: $PATH_ENV_FILE"
        exit 1
    }

    echo ""
    echo "✓ install.sh 完成安装"
    echo "  命令: run-docker"
    echo "  配置: $CONFIG_FILE"
    echo "  说明: 修改 user_container.yaml 后直接 run-docker，无需再次 install"
    echo "        飞书在 yaml 的 feishu 段配置：user_open_id；可选 app_id/app_secret（须成对）"
    echo "  公用账户: 每人可在 \$HOME/<个人目录>/ 放置 yaml，执行:"
    echo "        run-docker use-config \$HOME/zhangs1/yx_dockerspace/user_container.yaml"
    echo "        之后在个人目录及其子目录下 run-docker 自动使用该配置"
    if [ "$mode" = "release" ]; then
        echo "  清理发布包: cd .. && rm -rf run-docker-linux run-docker-linux.tar.gz"
    fi

    local rc_has_error=0
    for rc in "$HOME/.bashrc" "$HOME/.zshrc"; do
        [ -f "$rc" ] || continue
        if ! bash -n "$rc" 2>/dev/null; then
            rc_has_error=1
            echo "⚠ $rc 存在语法错误（不影响 run-docker，PATH 已写入 .bash_profile/.profile）"
            bash -n "$rc" 2>&1 | sed 's/^/    /' || true
        fi
    done

    if command -v run-docker &>/dev/null; then
        if _is_install_sourced; then
            echo "✓ run-docker 命令已在当前 shell 生效"
        else
            echo "✓ run-docker 命令已就绪（即将进入已配置 PATH 的 shell）"
        fi
    else
        echo "✗ run-docker 未在 PATH 中，请检查: $RUN_DOCKER_SCRIPT"
        echo "  或手动: source \"$PATH_ENV_FILE\""
        if _is_install_sourced; then
            return 1
        fi
        exit 1
    fi

    if [ "$rc_has_error" -eq 1 ]; then
        echo ""
        echo "  PATH 已写入 ~/.bash_profile / ~/.profile（登录后永久生效）"
        echo "  建议修复 .bashrc 语法错误（避免其他配置无法加载）"
    fi

    _enter_configured_shell
}

case "${1:-}" in
    --help|-h)
        echo "用法: $0 [选项]"
        echo ""
        echo "选项:"
        echo "  (无参数)            安装 run-docker（复制到 ~/.local/lib，可删除发布包目录）"
        echo "                      交互式 bash 安装结束后自动进入已配置 PATH 的 shell"
        echo "  source install.sh   在当前 shell 直接生效（不新开子 shell）"
        echo "  --dev               开发安装（从 run_codes/ 源码运行）"
        echo "  INSTALL_NO_REEXEC=1 bash install.sh  安装后不进入子 shell（脚本/CI 用）"
        echo "  --refresh-config    清理旧版 feishu.env，确认 yaml 为唯一配置入口"
        echo "  --uninstall|-u      卸载 run-docker（保留 ~/.config/auto_docker/ 配置）"
        echo "  --help              显示此帮助信息"
        echo ""
        echo "注意: 修改 ~/.config/auto_docker/user_container.yaml 后无需重新 install"
        echo ""
        echo "公用账户个人配置:"
        echo "  run-docker use-config \$HOME/<个人目录>/yx_dockerspace/user_container.yaml"
        echo "  绑定后在个人目录及其子目录下 run-docker 自动生效"
        ;;
    --refresh-config|--refresh)
        refresh_user_config
        ;;
    --dev)
        install_run_docker dev
        ;;
    --uninstall|-u)
        uninstall_run_docker
        echo "✓ 卸载完成（用户配置保留在 $CONFIG_DIR）"
        ;;
    *)
        install_run_docker release
        ;;
esac
